<template>
    <div>
       账号信息
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>